# Platformer

This is a platformer game I'm making. I'm not sure what the future of it will be.
Run `python3 main.py` to run.